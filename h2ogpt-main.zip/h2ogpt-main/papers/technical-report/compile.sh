#!/bin/bash
latexmk -pdf h2oGPT-TR.tex
